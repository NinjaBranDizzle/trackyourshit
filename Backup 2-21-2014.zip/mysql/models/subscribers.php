<?php
	class Subscribers{
		public static function getSubscriber($userId)
		{
			
		}
	}

?>